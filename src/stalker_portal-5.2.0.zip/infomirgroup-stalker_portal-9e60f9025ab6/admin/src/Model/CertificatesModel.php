<?php

namespace Model;

class CertificatesModel extends \Model\BaseStalkerModel {

    public function __construct() {
        parent::__construct();
    }
}